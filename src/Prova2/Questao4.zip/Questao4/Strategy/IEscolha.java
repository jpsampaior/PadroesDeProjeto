package Prova2.Questao4.Strategy;

public interface IEscolha {
    void minhaEscolha(String escolha);
}
