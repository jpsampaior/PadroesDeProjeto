package Prova2.Questao1.State;

public interface EstadoPersonagem {
    void atacar();
    void defender();
    void fugir();
}
