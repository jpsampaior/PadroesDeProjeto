package Prova2.Questao1.Strategy;

public interface IEscolha {
    void minhaEscolha(String string);
}
