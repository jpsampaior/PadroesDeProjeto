package Prova3.Proxy;

public class AutorizationKey {
    private String key;

    public AutorizationKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
