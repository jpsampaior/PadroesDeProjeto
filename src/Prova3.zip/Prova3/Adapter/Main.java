package Prova3.Adapter;

public class Main {
}
