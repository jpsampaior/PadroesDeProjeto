package Prova3.Adapter;

public interface IMidia {
    void carregarArquivo();
    void editarArquivo(String key);
}
