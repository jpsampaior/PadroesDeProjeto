package Prova3.Rascunho;

/*public interface IMidia {
    void carregarArquivo();
    void abrirArquivo();
    void editarArquivo();
}*/