package Prova3.Rascunho;

/*public class MidiaProxy implements IMidia {
    private String filename;
    private RealMidia realMidia;

    public MidiaProxy(String filename) {
        this.filename = filename;
    }

    @Override
    public void carregarArquivo() {
        if(realMidia == null) {
            realMidia = new RealMidia(filename);
        }
        realMidia.carregarArquivo();
    }

    @Override
    public void abrirArquivo() {
        if(realMidia == null) {
            carregarArquivo();
        }
        realMidia.abrirArquivo();
    }

    @Override
    public void editarArquivo() {
        if(realMidia == null) {
            carregarArquivo();
        }
        realMidia.editarArquivo();
    }
}*/
