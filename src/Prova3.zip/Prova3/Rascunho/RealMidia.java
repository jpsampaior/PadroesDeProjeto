package Prova3.Rascunho;

/*public class RealMidia implements IMidia {
    private final String filename;
    private final String key;

    public RealMidia(String filename, String key) {
        this.filename = filename;
        desbloqearArquivo(key,filename);
    }

    private void desbloqearArquivo(String key, String filename) {
        System.out.println("Desbloquendo o arquivo "+filename+" utilizando a chave: "+key);
    }

    @Override
    public void carregarArquivo() {
        System.out.println("Carregando arquivo "+filename);
    }

    @Override
    public void abrirArquivo() {
        System.out.println("Abrindo arquivo "+filename);
    }

    @Override
    public void editarArquivo() {
        System.out.println("Editando arquivo "+filename);
    }
}*/
